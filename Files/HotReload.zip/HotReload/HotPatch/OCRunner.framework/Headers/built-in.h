//
//  built-in.h
//  OCRunner
//
//  Created by Jiang on 2020/5/28.
//  Copyright © 2020 SilverFruity. All rights reserved.
//

#ifndef built_in_h
#define built_in_h
@class MFScopeChain;
extern void mf_add_built_in(MFScopeChain *scope);


#endif /* built_in_h */
